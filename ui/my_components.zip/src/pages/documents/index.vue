<template>
  <v-container>
    <v-flex>
      <documents-head/>
    </v-flex>
  </v-container>
</template>

<script>
 import DocumentsHead from '../../components/DocumentsHead'
 export default {
   name: 'Documents',
   components: {
     DocumentsHead
   }
 }
</script>
