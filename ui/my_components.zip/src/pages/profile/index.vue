<template>
  <v-container>
    <v-flex>
      <profile-head/>
    </v-flex>
  </v-container>
</template>

<script>
import ProfileHead from '../../components/ProfileHead'
export default {
  name: 'Profile',
  components: {
    ProfileHead
  }
}
</script>
