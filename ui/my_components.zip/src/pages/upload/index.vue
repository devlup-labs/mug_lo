<template>
 <upload-head/>
</template>
<script>
import UploadHead from '../../components/UploadHead'
export default{
  name: 'Upload',
  components: {
    UploadHead
  }
}
</script>
