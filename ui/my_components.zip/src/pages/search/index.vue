<template>
  <v-container>
    <v-flex>
      <search-head/>
    </v-flex>
  </v-container>
</template>

<script>
import SearchHead from '../../components/SearchHead'
export default {
  name: 'Search',
  components: {
    SearchHead
  }
}
</script>
