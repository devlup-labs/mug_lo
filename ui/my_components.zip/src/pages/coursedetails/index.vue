<template>
 <course-details/>
</template>

<script>
 import CourseDetails from '../../components/CourseDetails'
 export default {
   name: 'Details',
   components: {
     CourseDetails
   }
 }
</script>

